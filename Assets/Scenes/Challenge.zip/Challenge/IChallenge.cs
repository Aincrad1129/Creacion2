using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IChallenge
{
   
    void Complete();
    void Restart();
    bool getCompleted();
}
